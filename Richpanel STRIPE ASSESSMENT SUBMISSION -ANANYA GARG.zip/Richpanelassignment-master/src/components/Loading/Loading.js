import React from 'react'
import './Loading.css'
function Loading() {
  return (
    <div className='Loadermain'>
        <img src='https://miro.medium.com/max/1400/1*CsJ05WEGfunYMLGfsT2sXA.gif'/>
    </div>
  )
}

export default Loading 