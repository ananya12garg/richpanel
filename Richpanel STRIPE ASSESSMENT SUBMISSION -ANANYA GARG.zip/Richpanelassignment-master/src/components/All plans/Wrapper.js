import React from 'react'
import Plansexplore from './Plans'
 
import './../Home/Home.css'
 import Navbar from '../Navbar/Navbar'
function Wrapper() {
 
  return (
    <div>
        <Navbar></Navbar>
        <Plansexplore/></div>
  )
}

export default Wrapper