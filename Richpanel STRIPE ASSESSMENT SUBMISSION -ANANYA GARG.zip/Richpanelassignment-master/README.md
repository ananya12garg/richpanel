 # React stripe integration
 <h3>Live at</h3> https://richpanelfront.web.app
 
 ![image](https://user-images.githubusercontent.com/62851444/181343501-915f1cd1-491a-4b8e-bf23-72f6f9166b8d.png)
![image](https://user-images.githubusercontent.com/62851444/181343559-84040d85-1be2-40c1-a690-d1cf9f753a7c.png)
![image](https://user-images.githubusercontent.com/62851444/181343632-7e89be34-1834-43e6-a3e8-70a3ea2405c3.png)
![image](https://user-images.githubusercontent.com/62851444/181343677-fb2fffc6-5d41-405e-9dd9-cfc7776f23da.png)
![image](https://user-images.githubusercontent.com/62851444/181343720-42ed9ffc-8ed9-4bb1-9370-9c963f53ba17.png)
![image](https://user-images.githubusercontent.com/62851444/181343784-6b0393d5-dfb6-4e10-929b-7089d9d95307.png)
![image](https://user-images.githubusercontent.com/62851444/181343866-7a6c9518-cd9e-4a07-8375-a8ab1773f30f.png)
![image](https://user-images.githubusercontent.com/62851444/181343994-0363db1b-3a08-458c-b5d6-eeff0ff7d7a5.png)
